# IKS66EPG
EPG para canales latinos IPTV Merezco

EPG semanal creado para canales latinos de IPTV Merezco, Lista actualizarse, no bajar archivo, Usar el link siguiente:

https://raw.githubusercontent.com/Mcarv00/IKS66EPG/master/Merezco.xml




